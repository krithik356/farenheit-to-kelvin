f=int(input())
k=(75*f + 459.67)*5/9 
print(k)